//only used HTML/CSS bc I am still teaching myself JS (and HTML/CSS -- lol)
//inspired by one of my fave movies huehue (Spirited Away!)
//decided to learn some web development and do some coding while I rot away at home during quarantine